import type { CapacitorConfig } from '@capacitor/cli';

// This app is a thin native shell around the live site — it always loads
// bebetterbulletin.com directly rather than bundling a frozen copy, so the
// app shows whatever's live (today's rotating stories, reader spotlight,
// etc.) without needing a new store submission every time the site updates.
const config: CapacitorConfig = {
  appId: 'com.bebetterbulletin.app',
  appName: 'Be Better Bulletin',
  webDir: 'www',
  server: {
    url: 'https://bebetterbulletin.com',
    cleartext: false
  },
  ios: {
    contentInset: 'automatic'
  }
};

export default config;
