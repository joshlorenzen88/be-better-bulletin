package com.bebetterbulletin.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
